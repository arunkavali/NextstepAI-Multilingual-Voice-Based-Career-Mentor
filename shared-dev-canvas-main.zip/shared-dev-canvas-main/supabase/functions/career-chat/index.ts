import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { messages, language = 'en' } = await req.json();
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    
    if (!LOVABLE_API_KEY) {
      throw new Error("LOVABLE_API_KEY is not configured");
    }

    console.log("Starting career chat with", messages.length, "messages in language:", language);

    // System prompt for career guidance
    const systemPrompt = language === 'te' 
      ? `మీరు NextStep.AI యొక్క కెరీర్ మెంటర్. మీరు విద్యార్థులకు వారి ఆసక్తులు, నైపుణ్యాలు మరియు లక్ష్యాల ఆధారంగా వ్యక్తిగత కెరీర్ మార్గదర్శకత్వం అందిస్తారు. 

మీ విధానం:
1. విద్యార్థి ఆసక్తులు మరియు బలాలను అన్వేషించండి
2. వారి విద్య స్థాయి మరియు నేపథ్యాన్ని అర్థం చేసుకోండి
3. వ్యావహారిక కెరీర్ మార్గాలను సూచించండి
4. అవసరమైన నైపుణ్యాలు మరియు అర్హతలను వివరించండి
5. నేర్చుకునే వనరులు మరియు తదుపరి చర్యలను అందించండి

స్పష్టంగా, సానుభూతిపూర్వకంగా మరియు ప్రోత్సాహకరంగా ఉండండి. తెలుగులో ప్రతిస్పందించండి.`
      : `You are a career mentor for NextStep.AI. You provide personalized career guidance to students based on their interests, skills, and aspirations.

Your approach:
1. Explore the student's interests and strengths
2. Understand their education level and background
3. Suggest practical career paths with detailed explanations
4. Explain required skills and qualifications
5. Provide learning resources and next steps

Be clear, empathetic, and encouraging. Respond in English.`;

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          { role: "system", content: systemPrompt },
          ...messages,
        ],
        stream: true,
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(
          JSON.stringify({ error: "Rate limit exceeded. Please try again later." }),
          { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      if (response.status === 402) {
        return new Response(
          JSON.stringify({ error: "Payment required. Please add credits to your workspace." }),
          { status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      const errorText = await response.text();
      console.error("AI gateway error:", response.status, errorText);
      throw new Error("AI gateway error");
    }

    console.log("Streaming response from AI");
    return new Response(response.body, {
      headers: { ...corsHeaders, "Content-Type": "text/event-stream" },
    });

  } catch (error) {
    console.error("Career chat error:", error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : "Unknown error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
