import { useState, useRef, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { Card, CardContent } from '@/components/ui/card';
import { useCareerChat } from '@/hooks/useCareerChat';
import { useVoiceRecording } from '@/hooks/useVoiceRecording';
import { useTextToSpeech } from '@/hooks/useTextToSpeech';
import { Mic, Send, ArrowLeft, Volume2, VolumeX, Pause, Play, MessageSquare, Download, Brain, Mic as MicIcon, Map } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useToast } from '@/hooks/use-toast';
import { generateCareerRoadmap } from '@/utils/roadmapGenerator';

export default function Chat() {
  const { t, i18n } = useTranslation();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [input, setInput] = useState('');
  const [voiceEnabled, setVoiceEnabled] = useState(true);
  const [feedbackDialog, setFeedbackDialog] = useState<{ open: boolean; messageIndex: number }>({ open: false, messageIndex: -1 });
  const [feedbackRating, setFeedbackRating] = useState(3);
  const [feedbackComment, setFeedbackComment] = useState('');
  const [roadmapDialog, setRoadmapDialog] = useState(false);
  const [careerPathInput, setCareerPathInput] = useState('');
  const { messages, sendMessage, isLoading, conversationId, saveConversation } = useCareerChat();
  const { isRecording, startRecording, stopRecording } = useVoiceRecording();
  const { speak, pause, resume, stop, isSpeaking, isPaused } = useTextToSpeech();
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const handleStopRecording = async () => {
    const transcription = await stopRecording();
    if (transcription) {
      setInput(transcription);
    }
  };

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  useEffect(() => {
    if (voiceEnabled && messages.length > 0) {
      const lastMessage = messages[messages.length - 1];
      if (lastMessage.role === 'assistant' && !isLoading) {
        speak(lastMessage.content, i18n.language);
      }
    }
  }, [messages, voiceEnabled, isLoading, speak, i18n.language]);

  useEffect(() => {
    if (messages.length > 0 && !isLoading) {
      const timer = setTimeout(() => {
        saveConversation();
      }, 2000);
      return () => clearTimeout(timer);
    }
  }, [messages, isLoading, saveConversation]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;
    await sendMessage(input);
    setInput('');
  };

  const openRoadmapDialog = () => {
    const userMessages = messages.filter(m => m.role === 'user');
    if (userMessages.length > 0) {
      const lastUserMsg = userMessages[userMessages.length - 1].content;
      setCareerPathInput(lastUserMsg);
    }
    setRoadmapDialog(true);
  };

  const handleGenerateRoadmap = async () => {
    if (!careerPathInput.trim()) {
      toast({
        title: t('chat.error'),
        description: 'Please enter a career path',
        variant: 'destructive'
      });
      return;
    }

    try {
      setRoadmapDialog(false);
      const result = await generateCareerRoadmap(careerPathInput, '', i18n.language);

      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        const { data: savedRoadmap } = await supabase
          .from('roadmaps')
          .insert({
            user_id: user.id,
            career_path: result.careerPath,
            image_url: result.imageUrl,
            description: result.message,
            conversation_id: conversationId,
          })
          .select()
          .maybeSingle();

        if (savedRoadmap) {
          navigate(`/roadmap/${savedRoadmap.id}`);
        }
      }

      toast({
        title: t('chat.roadmapGenerated'),
        description: t('chat.roadmapSuccess')
      });
    } catch (error: any) {
      toast({
        title: t('chat.error'),
        description: error.message,
        variant: 'destructive'
      });
    }
  };

  const openFeedbackDialog = (messageIndex: number) => {
    setFeedbackDialog({ open: true, messageIndex });
    setFeedbackRating(3);
    setFeedbackComment('');
  };

  const submitFeedback = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      await supabase.from('feedback').insert({
        user_id: user.id,
        message_index: feedbackDialog.messageIndex,
        rating: feedbackRating,
        comment: feedbackComment
      });

      toast({ title: t('chat.feedbackSubmitted') });
      setFeedbackDialog({ open: false, messageIndex: -1 });
    } catch (error: any) {
      toast({
        title: t('chat.error'),
        description: error.message,
        variant: 'destructive'
      });
    }
  };

  const quickStartQuestions = [
    "What career suits someone interested in technology and problem-solving?",
    "I love creative work and design. What are my options?",
    "How do I transition into data science from a different field?",
    "What skills should I learn for digital marketing?"
  ];

  return (
    <div className="flex flex-col h-screen bg-gradient-to-br from-[#f8f9ff] via-[#fefeff] to-[#f5f7ff]">
      <div className="border-b bg-white/80 backdrop-blur-md shadow-sm p-4 sticky top-0 z-10">
        <div className="container mx-auto flex items-center gap-4 max-w-7xl">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate('/dashboard')}
            aria-label={t('common.back')}
            className="hover:bg-gray-100"
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#7a5cf5] to-[#6a4ce5] flex items-center justify-center">
              <Brain className="h-5 w-5 text-white" />
            </div>
            <h1 className="text-xl font-bold text-gray-900">AI Career Mentor</h1>
          </div>
          <div className="ml-auto flex gap-2">
            <Button
              variant="outline"
              size="icon"
              onClick={() => setVoiceEnabled(!voiceEnabled)}
              aria-label={voiceEnabled ? t('chat.disableVoice') : t('chat.enableVoice')}
              className="min-w-[44px] min-h-[44px] hover:bg-gray-100"
            >
              {voiceEnabled ? <Volume2 className="h-4 w-4" /> : <VolumeX className="h-4 w-4" />}
            </Button>
            {isSpeaking && (
              <Button
                variant="outline"
                size="icon"
                onClick={isPaused ? resume : pause}
                aria-label={isPaused ? t('chat.resumeVoice') : t('chat.pauseVoice')}
                className="min-w-[44px] min-h-[44px] hover:bg-gray-100"
              >
                {isPaused ? <Play className="h-4 w-4" /> : <Pause className="h-4 w-4" />}
              </Button>
            )}
            <Button
              variant="outline"
              size="sm"
              onClick={openRoadmapDialog}
              disabled={messages.length === 0}
              className="min-h-[44px] hover:bg-gray-100"
            >
              <Map className="mr-2 h-4 w-4" />
              Roadmap
            </Button>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto">
        <div className="container mx-auto max-w-7xl p-4">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 space-y-4">
              <Card className="shadow-lg border-0">
                <CardContent className="p-6">
                  <div className="flex items-center gap-2 mb-4">
                    <MessageSquare className="h-5 w-5 text-[#7a5cf5]" />
                    <h2 className="text-lg font-semibold text-gray-900">Chat with Your AI Mentor</h2>
                  </div>
                  <p className="text-sm text-gray-600 mb-4">
                    Ask questions about your career, interests, skills, and goals. Use voice input for a more natural conversation experience.
                  </p>

                  <div className="space-y-4 min-h-[400px] max-h-[500px] overflow-y-auto p-4 bg-gray-50 rounded-lg">
                    <AnimatePresence>
                      {messages.map((message, index) => (
                        <motion.div
                          key={index}
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: -10 }}
                          className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
                        >
                          <div className={`flex gap-3 max-w-[85%] ${message.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
                            <div className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center ${
                              message.role === 'user'
                                ? 'bg-gradient-to-br from-blue-500 to-blue-600'
                                : 'bg-gradient-to-br from-[#7a5cf5] to-[#6a4ce5]'
                            }`}>
                              {message.role === 'user' ? (
                                <span className="text-white text-sm font-semibold">U</span>
                              ) : (
                                <Brain className="h-4 w-4 text-white" />
                              )}
                            </div>
                            <div className="flex flex-col gap-1">
                              <div
                                className={`rounded-2xl p-4 ${
                                  message.role === 'user'
                                    ? 'bg-gradient-to-br from-blue-500 to-blue-600 text-white'
                                    : 'bg-white shadow-md text-gray-900'
                                }`}
                                role="article"
                                aria-label={message.role === 'user' ? t('chat.userMessage') : t('chat.aiMessage')}
                              >
                                <p className="whitespace-pre-wrap text-sm leading-relaxed">{message.content}</p>
                              </div>
                              {message.role === 'assistant' && (
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => openFeedbackDialog(index)}
                                  className="h-7 self-start text-xs text-gray-500 hover:text-gray-700"
                                >
                                  <MessageSquare className="h-3 w-3 mr-1" />
                                  {t('chat.feedback')}
                                </Button>
                              )}
                            </div>
                          </div>
                        </motion.div>
                      ))}
                    </AnimatePresence>
                    {isLoading && (
                      <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        className="flex justify-start"
                      >
                        <div className="flex gap-3 max-w-[85%]">
                          <div className="flex-shrink-0 w-8 h-8 rounded-full bg-gradient-to-br from-[#7a5cf5] to-[#6a4ce5] flex items-center justify-center">
                            <Brain className="h-4 w-4 text-white" />
                          </div>
                          <div className="bg-white rounded-2xl p-4 shadow-md">
                            <div className="flex gap-2">
                              <div className="w-2 h-2 bg-[#7a5cf5] rounded-full animate-bounce" />
                              <div className="w-2 h-2 bg-[#7a5cf5] rounded-full animate-bounce delay-100" />
                              <div className="w-2 h-2 bg-[#7a5cf5] rounded-full animate-bounce delay-200" />
                            </div>
                          </div>
                        </div>
                      </motion.div>
                    )}
                    <div ref={messagesEndRef} />
                  </div>

                  <div className="mt-4 flex gap-2">
                    <Textarea
                      value={input}
                      onChange={(e) => setInput(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter' && !e.shiftKey) {
                          e.preventDefault();
                          handleSend();
                        }
                      }}
                      placeholder="Type your message or click the mic button..."
                      className="min-h-[60px] text-base resize-none"
                      aria-label={t('chat.inputLabel')}
                    />
                    <div className="flex flex-col gap-2">
                      <Button
                        size="icon"
                        variant={isRecording ? 'destructive' : 'outline'}
                        onClick={isRecording ? handleStopRecording : startRecording}
                        aria-label={isRecording ? t('chat.stopRecording') : t('chat.startRecording')}
                        className="min-w-[44px] min-h-[44px]"
                      >
                        <Mic className={`h-5 w-5 ${isRecording ? 'animate-pulse' : ''}`} />
                      </Button>
                      <Button
                        size="icon"
                        onClick={handleSend}
                        disabled={!input.trim() || isLoading}
                        aria-label={t('chat.sendMessage')}
                        className="min-w-[44px] min-h-[44px] bg-[#7a5cf5] hover:bg-[#6a4ce5]"
                      >
                        <Send className="h-5 w-5" />
                      </Button>
                    </div>
                  </div>

                  {messages.length > 0 && (
                    <div className="mt-4 pt-4 border-t">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={openRoadmapDialog}
                        className="w-full"
                      >
                        <Download className="mr-2 h-4 w-4" />
                        Download Career Path PDF
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>

              {messages.length === 0 && (
                <Card className="shadow-lg border-0">
                  <CardContent className="p-6">
                    <h3 className="font-semibold text-gray-900 mb-4">Quick Start Questions</h3>
                    <div className="space-y-2">
                      {quickStartQuestions.map((question, index) => (
                        <motion.button
                          key={index}
                          whileHover={{ scale: 1.02 }}
                          whileTap={{ scale: 0.98 }}
                          className="w-full text-left p-3 rounded-lg bg-gray-50 hover:bg-gray-100 text-sm text-gray-700 transition-colors"
                          onClick={() => setInput(question)}
                        >
                          {question}
                        </motion.button>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>

            <div className="space-y-6">
              <Card className="shadow-lg border-0">
                <CardContent className="p-6">
                  <div className="flex items-center gap-2 mb-4">
                    <Map className="h-5 w-5 text-[#7a5cf5]" />
                    <h2 className="text-lg font-semibold text-gray-900">Career Roadmap & Resources</h2>
                  </div>
                  <p className="text-sm text-gray-600 mb-4">
                    Visual representations of your career path, required skills, and learning resources will appear here as you chat.
                  </p>

                  <div className="bg-gradient-to-br from-gray-50 to-gray-100 rounded-lg p-8 text-center">
                    <div className="w-16 h-16 rounded-full bg-[#7a5cf5]/10 flex items-center justify-center mx-auto mb-4">
                      <Map className="h-8 w-8 text-[#7a5cf5]" />
                    </div>
                    <h3 className="font-semibold text-gray-900 mb-2">Career Path Visualization</h3>
                    <p className="text-sm text-gray-600 mb-4">
                      Career visualization will appear here. Continue chatting to generate your roadmap.
                    </p>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={openRoadmapDialog}
                      disabled={messages.length === 0}
                    >
                      Generate Now
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-6">
            <motion.div whileHover={{ y: -4 }} className="transition-all">
              <Card className="shadow-lg border-0 text-center">
                <CardContent className="p-6">
                  <div className="w-12 h-12 rounded-full bg-[#7a5cf5]/10 flex items-center justify-center mx-auto mb-3">
                    <Brain className="h-6 w-6 text-[#7a5cf5]" />
                  </div>
                  <h3 className="font-semibold text-gray-900 mb-2">AI-Powered Guidance</h3>
                  <p className="text-sm text-gray-600">
                    Get personalized career advice based on your unique interests and goals
                  </p>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div whileHover={{ y: -4 }} className="transition-all">
              <Card className="shadow-lg border-0 text-center">
                <CardContent className="p-6">
                  <div className="w-12 h-12 rounded-full bg-[#7a5cf5]/10 flex items-center justify-center mx-auto mb-3">
                    <MicIcon className="h-6 w-6 text-[#7a5cf5]" />
                  </div>
                  <h3 className="font-semibold text-gray-900 mb-2">Voice Interaction</h3>
                  <p className="text-sm text-gray-600">
                    Speak naturally and get voice responses for a conversational experience
                  </p>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div whileHover={{ y: -4 }} className="transition-all">
              <Card className="shadow-lg border-0 text-center">
                <CardContent className="p-6">
                  <div className="w-12 h-12 rounded-full bg-[#7a5cf5]/10 flex items-center justify-center mx-auto mb-3">
                    <Map className="h-6 w-6 text-[#7a5cf5]" />
                  </div>
                  <h3 className="font-semibold text-gray-900 mb-2">Visual Roadmaps</h3>
                  <p className="text-sm text-gray-600">
                    See your career path visualized with clear steps and milestones
                  </p>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>
      </div>

      <Dialog open={roadmapDialog} onOpenChange={setRoadmapDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{t('chat.generateRoadmap')}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>{t('chat.careerPathLabel')}</Label>
              <Textarea
                value={careerPathInput}
                onChange={(e) => setCareerPathInput(e.target.value)}
                placeholder={t('chat.careerPathPlaceholder')}
                className="min-h-[100px]"
              />
            </div>
            <Button onClick={handleGenerateRoadmap} className="w-full bg-[#7a5cf5] hover:bg-[#6a4ce5]">
              {t('chat.generateVisualRoadmap')}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={feedbackDialog.open} onOpenChange={(open) => setFeedbackDialog({ ...feedbackDialog, open })}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{t('chat.provideFeedback')}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>{t('chat.rating')}: {feedbackRating}/5</Label>
              <Slider
                value={[feedbackRating]}
                onValueChange={(val) => setFeedbackRating(val[0])}
                min={1}
                max={5}
                step={1}
                className="w-full"
              />
            </div>
            <div className="space-y-2">
              <Label>{t('chat.feedbackComment')}</Label>
              <Textarea
                value={feedbackComment}
                onChange={(e) => setFeedbackComment(e.target.value)}
                placeholder={t('chat.feedbackPlaceholder')}
                className="min-h-[100px]"
              />
            </div>
            <Button onClick={submitFeedback} className="w-full bg-[#7a5cf5] hover:bg-[#6a4ce5]">
              {t('chat.submitFeedback')}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
