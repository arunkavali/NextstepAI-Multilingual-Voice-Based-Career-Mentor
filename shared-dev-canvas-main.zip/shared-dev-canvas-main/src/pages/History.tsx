import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ArrowLeft, MessageSquare, Map, Trash2, RefreshCw, Download, Search, Filter } from 'lucide-react';
import { motion } from 'framer-motion';
import { useToast } from '@/hooks/use-toast';
import { usePullToRefresh } from '@/hooks/usePullToRefresh';

export default function History() {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [conversations, setConversations] = useState<any[]>([]);
  const [roadmaps, setRoadmaps] = useState<any[]>([]);
  const [filteredConversations, setFilteredConversations] = useState<any[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [dateFilter, setDateFilter] = useState('all');
  const [activeTab, setActiveTab] = useState<'conversations' | 'roadmaps'>('conversations');

  useEffect(() => {
    loadConversations();
  }, []);

  useEffect(() => {
    filterConversations();
  }, [searchQuery, dateFilter, conversations]);

  const loadConversations = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    const { data: conversationsData } = await supabase
      .from('conversations')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false });

    const { data: roadmapsData } = await supabase
      .from('roadmaps')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false });

    setConversations(conversationsData || []);
    setRoadmaps(roadmapsData || []);
  };

  const filterConversations = () => {
    let filtered = [...conversations];

    if (searchQuery) {
      filtered = filtered.filter(conv => 
        (conv.title || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
        JSON.stringify(conv.messages || []).toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    if (dateFilter !== 'all') {
      const now = new Date();
      filtered = filtered.filter(conv => {
        const convDate = new Date(conv.created_at);
        const daysDiff = Math.floor((now.getTime() - convDate.getTime()) / (1000 * 60 * 60 * 24));
        
        switch (dateFilter) {
          case 'today': return daysDiff === 0;
          case 'week': return daysDiff <= 7;
          case 'month': return daysDiff <= 30;
          default: return true;
        }
      });
    }

    setFilteredConversations(filtered);
  };

  const exportAllData = async () => {
    const dataStr = JSON.stringify(conversations, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
    const exportFileDefaultName = `nextstep-conversations-${new Date().toISOString()}.json`;
    
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
    
    toast({ title: t('history.exported') });
  };

  const getMessagePreview = (messages: any[]) => {
    if (!messages || messages.length === 0) return '';
    const firstMessage = messages.find((m: any) => m.role === 'user');
    return firstMessage?.content?.substring(0, 100) + '...' || '';
  };

  const handleDelete = async (id: string) => {
    const { error } = await supabase
      .from('conversations')
      .delete()
      .eq('id', id);

    if (error) {
      toast({
        title: t('history.error'),
        description: error.message,
        variant: 'destructive'
      });
    } else {
      toast({ title: t('history.deleted') });
      loadConversations();
    }
  };

  const { containerRef, isPulling, isRefreshing, pullDistance } = usePullToRefresh({
    onRefresh: loadConversations,
    threshold: 80
  });

  return (
    <div 
      ref={containerRef}
      className="min-h-screen bg-gradient-to-b from-background to-muted/20 overflow-y-auto"
      style={{ touchAction: 'pan-y' }}
    >
      {(isPulling || isRefreshing) && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="fixed top-0 left-1/2 -translate-x-1/2 z-50 pt-4"
        >
          <div className="bg-card rounded-full p-3 shadow-elegant">
            <RefreshCw 
              className={`h-5 w-5 text-primary ${isRefreshing ? 'animate-spin' : ''}`}
              style={{
                transform: isPulling ? `rotate(${pullDistance * 3}deg)` : undefined
              }}
            />
          </div>
        </motion.div>
      )}
      <div className="container mx-auto px-4 py-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-8"
        >
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon" onClick={() => navigate('/dashboard')}>
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <h1 className="text-3xl font-bold bg-gradient-to-r from-primary via-secondary to-accent bg-clip-text text-transparent">
                {t('history.title')}
              </h1>
            </div>
            <Button onClick={exportAllData} variant="outline">
              <Download className="mr-2 h-4 w-4" />
              {t('history.exportAll')}
            </Button>
          </div>

          <Card className="shadow-elegant">
            <CardContent className="pt-6 space-y-4">
              <div className="flex gap-2 mb-4 border-b">
                <Button
                  variant={activeTab === 'conversations' ? 'default' : 'ghost'}
                  onClick={() => setActiveTab('conversations')}
                  className="flex-1"
                >
                  <MessageSquare className="mr-2 h-4 w-4" />
                  {t('history.conversations')} ({conversations.length})
                </Button>
                <Button
                  variant={activeTab === 'roadmaps' ? 'default' : 'ghost'}
                  onClick={() => setActiveTab('roadmaps')}
                  className="flex-1"
                >
                  <Map className="mr-2 h-4 w-4" />
                  {t('history.roadmaps')} ({roadmaps.length})
                </Button>
              </div>
              
              {activeTab === 'conversations' && (
                <div className="flex flex-col sm:flex-row gap-4">
                  <div className="flex-1 relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder={t('history.search')}
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-9"
                    />
                  </div>
                  <Select value={dateFilter} onValueChange={setDateFilter}>
                    <SelectTrigger className="w-full sm:w-[180px]">
                      <Filter className="mr-2 h-4 w-4" />
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">{t('history.filterAll')}</SelectItem>
                      <SelectItem value="today">{t('history.filterToday')}</SelectItem>
                      <SelectItem value="week">{t('history.filterWeek')}</SelectItem>
                      <SelectItem value="month">{t('history.filterMonth')}</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              )}
            </CardContent>
          </Card>

          {activeTab === 'conversations' ? (
            <div className="grid gap-4">
              {filteredConversations.map((conv) => (
                <Card key={conv.id} className="shadow-elegant">
                  <CardHeader className="flex flex-row items-center justify-between">
                    <CardTitle className="flex items-center gap-2">
                      <MessageSquare className="h-5 w-5" />
                      {conv.title || t('history.untitled')}
                    </CardTitle>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleDelete(conv.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <p className="text-sm text-muted-foreground line-clamp-2">
                      {getMessagePreview(conv.messages)}
                    </p>
                    <div className="flex items-center justify-between">
                      <p className="text-xs text-muted-foreground">
                        {new Date(conv.created_at).toLocaleDateString()} • {conv.messages?.length || 0} {t('history.messages')}
                      </p>
                      <Button 
                        variant="ghost" 
                        size="sm"
                        onClick={() => navigate(`/chat/${conv.id}`)}
                      >
                        {t('history.view')}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
              {filteredConversations.length === 0 && conversations.length > 0 && (
                <p className="text-center text-muted-foreground">
                  {t('history.noResults')}
                </p>
              )}
              {conversations.length === 0 && (
                <p className="text-center text-muted-foreground">
                  {t('history.empty')}
                </p>
              )}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {roadmaps.map((roadmap) => (
                <Card 
                  key={roadmap.id} 
                  className="shadow-elegant cursor-pointer hover:shadow-glow transition-all"
                  onClick={() => navigate(`/roadmap/${roadmap.id}`)}
                >
                  <div className="aspect-video w-full overflow-hidden rounded-t-lg bg-muted">
                    {roadmap.image_url && (
                      <img 
                        src={roadmap.image_url} 
                        alt={roadmap.career_path}
                        className="w-full h-full object-cover"
                      />
                    )}
                  </div>
                  <CardContent className="p-4">
                    <h3 className="font-semibold mb-2 line-clamp-1">{roadmap.career_path}</h3>
                    <p className="text-xs text-muted-foreground">
                      {new Date(roadmap.created_at).toLocaleDateString()}
                    </p>
                  </CardContent>
                </Card>
              ))}
              {roadmaps.length === 0 && (
                <p className="text-center text-muted-foreground col-span-full">
                  {t('history.noRoadmaps')}
                </p>
              )}
            </div>
          )}
        </motion.div>
      </div>
    </div>
  );
}
