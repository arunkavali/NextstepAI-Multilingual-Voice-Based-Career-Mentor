import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { ArrowLeft, Download } from 'lucide-react';
import { downloadRoadmapImage } from '@/utils/roadmapGenerator';

export default function Roadmap() {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const { id } = useParams();
  const [roadmapData, setRoadmapData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (id) {
      loadRoadmap();
    }
  }, [id]);

  const loadRoadmap = async () => {
    try {
      const { data, error } = await supabase
        .from('roadmaps')
        .select('*')
        .eq('id', id)
        .single();

      if (error) throw error;
      setRoadmapData(data);
    } catch (error) {
      console.error('Failed to load roadmap:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <Card className="p-6 text-center">
          <p className="text-muted-foreground">{t('common.loading')}</p>
        </Card>
      </div>
    );
  }

  if (!roadmapData) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <Card className="p-6 text-center">
          <p className="text-muted-foreground mb-4">No roadmap data available</p>
          <Button onClick={() => navigate('/chat')}>
            {t('common.back')}
          </Button>
        </Card>
      </div>
    );
  }

  const handleDownload = () => {
    downloadRoadmapImage(roadmapData.image_url, `${roadmapData.career_path}-roadmap.png`);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted/20">
      <div className="border-b bg-card/50 backdrop-blur p-4">
        <div className="container mx-auto flex items-center gap-4">
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={() => navigate('/chat')}
            aria-label={t('common.back')}
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-xl font-bold">{t('roadmap.title')}</h1>
          <div className="ml-auto">
            <Button
              variant="outline"
              size="sm"
              onClick={handleDownload}
            >
              <Download className="mr-2 h-4 w-4" />
              {t('roadmap.download')}
            </Button>
          </div>
        </div>
      </div>

      <div className="container mx-auto p-4 max-w-5xl">
        <Card className="p-6">
          <h2 className="text-2xl font-bold mb-4">{roadmapData.career_path}</h2>
          {roadmapData.description && (
            <p className="text-muted-foreground mb-6">{roadmapData.description}</p>
          )}
          <div className="relative w-full rounded-lg overflow-hidden bg-muted">
            <img 
              src={roadmapData.image_url} 
              alt={`Career roadmap for ${roadmapData.career_path}`}
              className="w-full h-auto"
            />
          </div>
        </Card>
      </div>
    </div>
  );
}
