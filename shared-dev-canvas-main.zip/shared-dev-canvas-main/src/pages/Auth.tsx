import { useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { motion } from 'framer-motion';

export default function Auth() {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const mode = searchParams.get('mode') || 'login';
  const { toast } = useToast();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [loading, setLoading] = useState(false);

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      if (mode === 'signup') {
        const { error } = await supabase.auth.signUp({
          email,
          password,
          options: {
            data: { full_name: fullName },
            emailRedirectTo: `${window.location.origin}/dashboard`
          }
        });
        if (error) throw error;
        toast({
          title: t('auth.signupSuccess'),
          description: t('auth.checkEmail')
        });
      } else if (mode === 'login') {
        const { error } = await supabase.auth.signInWithPassword({
          email,
          password
        });
        if (error) throw error;
        navigate('/dashboard');
      } else if (mode === 'reset') {
        const { error } = await supabase.auth.resetPasswordForEmail(email, {
          redirectTo: `${window.location.origin}/auth?mode=update-password`
        });
        if (error) throw error;
        toast({
          title: t('auth.resetSent'),
          description: t('auth.checkEmailReset')
        });
      }
    } catch (error: any) {
      toast({
        title: t('auth.error'),
        description: error.message,
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-b from-background to-muted/20 px-4">
      <motion.div
        className="w-full max-w-md space-y-8"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <div className="text-center">
          <h1 className="text-3xl font-bold bg-gradient-to-r from-primary via-secondary to-accent bg-clip-text text-transparent">
            {mode === 'signup' ? t('auth.signup') : mode === 'reset' ? t('auth.resetPassword') : t('auth.login')}
          </h1>
        </div>

        <form onSubmit={handleAuth} className="space-y-6 bg-card p-8 rounded-lg shadow-elegant">
          {mode === 'signup' && (
            <div className="space-y-2">
              <Label htmlFor="fullName">{t('auth.fullName')}</Label>
              <Input
                id="fullName"
                type="text"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                required
              />
            </div>
          )}

          <div className="space-y-2">
            <Label htmlFor="email">{t('auth.email')}</Label>
            <Input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>

          {mode !== 'reset' && (
            <div className="space-y-2">
              <Label htmlFor="password">{t('auth.password')}</Label>
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                minLength={6}
              />
            </div>
          )}

          <Button type="submit" className="w-full" disabled={loading}>
            {loading ? t('auth.loading') : mode === 'signup' ? t('auth.signup') : mode === 'reset' ? t('auth.sendReset') : t('auth.login')}
          </Button>

          <div className="text-center text-sm space-y-2">
            {mode === 'login' && (
              <>
                <button
                  type="button"
                  onClick={() => navigate('/auth?mode=reset')}
                  className="text-primary hover:underline"
                >
                  {t('auth.forgotPassword')}
                </button>
                <div>
                  {t('auth.noAccount')}{' '}
                  <button
                    type="button"
                    onClick={() => navigate('/auth?mode=signup')}
                    className="text-primary hover:underline"
                  >
                    {t('auth.signupLink')}
                  </button>
                </div>
              </>
            )}
            {mode === 'signup' && (
              <div>
                {t('auth.hasAccount')}{' '}
                <button
                  type="button"
                  onClick={() => navigate('/auth?mode=login')}
                  className="text-primary hover:underline"
                >
                  {t('auth.loginLink')}
                </button>
              </div>
            )}
            {mode === 'reset' && (
              <button
                type="button"
                onClick={() => navigate('/auth?mode=login')}
                className="text-primary hover:underline"
              >
                {t('auth.backToLogin')}
              </button>
            )}
          </div>
        </form>
      </motion.div>
    </div>
  );
}
