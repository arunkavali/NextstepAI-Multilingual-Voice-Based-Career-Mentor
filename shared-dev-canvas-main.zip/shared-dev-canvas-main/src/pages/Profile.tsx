import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { ArrowLeft, Upload, X } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { motion } from 'framer-motion';

const CAREER_INTERESTS_OPTIONS = [
  'Technology', 'Healthcare', 'Business', 'Education', 'Arts', 'Engineering',
  'Science', 'Finance', 'Marketing', 'Design', 'Law', 'Media', 'Sports'
];

export default function Profile() {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [profile, setProfile] = useState({
    full_name: '',
    age: '',
    education_level: '',
    language_preference: 'en',
    avatar_url: '',
    career_interests: [] as string[]
  });

  useEffect(() => {
    loadProfile();
  }, []);

  const loadProfile = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    const { data } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', user.id)
      .single();

    if (data) {
      setProfile({
        full_name: data.full_name || '',
        age: data.age?.toString() || '',
        education_level: data.education_level || '',
        language_preference: data.language_preference || 'en',
        avatar_url: data.avatar_url || '',
        career_interests: data.career_interests || []
      });
    }
  };

  const handleAvatarUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 2 * 1024 * 1024) {
      toast({
        title: t('profile.error'),
        description: t('profile.fileTooLarge'),
        variant: 'destructive'
      });
      return;
    }

    setUploading(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      const fileExt = file.name.split('.').pop();
      const fileName = `${user.id}/${Date.now()}.${fileExt}`;

      const { error: uploadError } = await supabase.storage
        .from('avatars')
        .upload(fileName, file, { upsert: true });

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from('avatars')
        .getPublicUrl(fileName);

      setProfile({ ...profile, avatar_url: publicUrl });

      toast({ title: t('profile.avatarUploaded') });
    } catch (error: any) {
      toast({
        title: t('profile.error'),
        description: error.message,
        variant: 'destructive'
      });
    } finally {
      setUploading(false);
    }
  };

  const toggleInterest = (interest: string) => {
    setProfile({
      ...profile,
      career_interests: profile.career_interests.includes(interest)
        ? profile.career_interests.filter(i => i !== interest)
        : [...profile.career_interests, interest]
    });
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      const { error } = await supabase
        .from('profiles')
        .update({
          full_name: profile.full_name,
          age: profile.age ? parseInt(profile.age) : null,
          education_level: profile.education_level,
          language_preference: profile.language_preference,
          avatar_url: profile.avatar_url,
          career_interests: profile.career_interests
        })
        .eq('id', user.id);

      if (error) throw error;

      toast({
        title: t('profile.saved'),
        description: t('profile.saveSuccess')
      });
    } catch (error: any) {
      toast({
        title: t('profile.error'),
        description: error.message,
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted/20">
      <div className="container mx-auto px-4 py-8 max-w-2xl">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-8"
        >
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate('/dashboard')}>
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-primary via-secondary to-accent bg-clip-text text-transparent">
              {t('profile.title')}
            </h1>
          </div>

          <form onSubmit={handleSave} className="space-y-6 bg-card p-8 rounded-lg shadow-elegant">
            <div className="flex flex-col items-center gap-4">
              <Avatar className="h-24 w-24">
                <AvatarImage src={profile.avatar_url} alt={profile.full_name} />
                <AvatarFallback className="text-2xl">
                  {profile.full_name.split(' ').map(n => n[0]).join('').toUpperCase() || '?'}
                </AvatarFallback>
              </Avatar>
              <div>
                <input
                  type="file"
                  id="avatar-upload"
                  accept="image/*"
                  onChange={handleAvatarUpload}
                  className="hidden"
                />
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => document.getElementById('avatar-upload')?.click()}
                  disabled={uploading}
                >
                  <Upload className="mr-2 h-4 w-4" />
                  {uploading ? t('profile.uploading') : t('profile.uploadAvatar')}
                </Button>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="fullName">{t('profile.fullName')}</Label>
              <Input
                id="fullName"
                value={profile.full_name}
                onChange={(e) => setProfile({ ...profile, full_name: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="age">{t('profile.age')}</Label>
              <Input
                id="age"
                type="number"
                value={profile.age}
                onChange={(e) => setProfile({ ...profile, age: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="education">{t('profile.education')}</Label>
              <Input
                id="education"
                value={profile.education_level}
                onChange={(e) => setProfile({ ...profile, education_level: e.target.value })}
              />
            </div>

            <div className="space-y-3">
              <Label>{t('profile.careerInterests')}</Label>
              <div className="flex flex-wrap gap-2">
                {CAREER_INTERESTS_OPTIONS.map((interest) => (
                  <Badge
                    key={interest}
                    variant={profile.career_interests.includes(interest) ? 'default' : 'outline'}
                    className="cursor-pointer select-none"
                    onClick={() => toggleInterest(interest)}
                  >
                    {interest}
                    {profile.career_interests.includes(interest) && (
                      <X className="ml-1 h-3 w-3" />
                    )}
                  </Badge>
                ))}
              </div>
            </div>

            <Button type="submit" className="w-full" disabled={loading}>
              {loading ? t('profile.saving') : t('profile.save')}
            </Button>
          </form>
        </motion.div>
      </div>
    </div>
  );
}
