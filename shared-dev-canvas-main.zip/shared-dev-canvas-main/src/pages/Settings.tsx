import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { ArrowLeft, Download } from 'lucide-react';
import { motion } from 'framer-motion';
import { useToast } from '@/hooks/use-toast';

export default function Settings() {
  const { t, i18n } = useTranslation();
  const navigate = useNavigate();
  const { toast } = useToast();
  
  const [voiceSpeed, setVoiceSpeed] = useState(1);
  const [voicePitch, setVoicePitch] = useState(1);
  const [notificationsEnabled, setNotificationsEnabled] = useState(false);

  useEffect(() => {
    // Load saved voice settings
    const savedSpeed = localStorage.getItem('voiceSpeed');
    const savedPitch = localStorage.getItem('voicePitch');
    const savedNotifications = localStorage.getItem('notificationsEnabled');
    
    if (savedSpeed) setVoiceSpeed(parseFloat(savedSpeed));
    if (savedPitch) setVoicePitch(parseFloat(savedPitch));
    if (savedNotifications) setNotificationsEnabled(savedNotifications === 'true');
  }, []);

  const handleLanguageChange = (value: string) => {
    i18n.changeLanguage(value);
    localStorage.setItem('language', value);
  };

  const handleVoiceSpeedChange = (value: number[]) => {
    setVoiceSpeed(value[0]);
    localStorage.setItem('voiceSpeed', value[0].toString());
  };

  const handleVoicePitchChange = (value: number[]) => {
    setVoicePitch(value[0]);
    localStorage.setItem('voicePitch', value[0].toString());
  };

  const handleNotificationsToggle = (checked: boolean) => {
    setNotificationsEnabled(checked);
    localStorage.setItem('notificationsEnabled', checked.toString());
    
    if (checked && 'Notification' in window) {
      Notification.requestPermission();
    }
  };

  const exportUserData = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const [profile, conversations, roadmaps] = await Promise.all([
        supabase.from('profiles').select('*').eq('id', user.id).single(),
        supabase.from('conversations').select('*').eq('user_id', user.id),
        supabase.from('roadmaps').select('*').eq('user_id', user.id)
      ]);

      const exportData = {
        profile: profile.data,
        conversations: conversations.data,
        roadmaps: roadmaps.data,
        exportedAt: new Date().toISOString()
      };

      const dataStr = JSON.stringify(exportData, null, 2);
      const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
      const exportFileDefaultName = `nextstep-data-${new Date().toISOString()}.json`;
      
      const linkElement = document.createElement('a');
      linkElement.setAttribute('href', dataUri);
      linkElement.setAttribute('download', exportFileDefaultName);
      linkElement.click();
      
      toast({ title: t('settings.dataExported') });
    } catch (error: any) {
      toast({
        title: t('settings.error'),
        description: error.message,
        variant: 'destructive'
      });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted/20">
      <div className="container mx-auto px-4 py-8 max-w-2xl">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-8"
        >
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate('/dashboard')}>
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-primary via-secondary to-accent bg-clip-text text-transparent">
              {t('settings.title')}
            </h1>
          </div>

          <Card className="shadow-elegant">
            <CardHeader>
              <CardTitle>{t('settings.language')}</CardTitle>
              <CardDescription>{t('settings.languageDescription')}</CardDescription>
            </CardHeader>
            <CardContent>
              <Select value={i18n.language} onValueChange={handleLanguageChange}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="en">English</SelectItem>
                  <SelectItem value="te">తెలుగు (Telugu)</SelectItem>
                </SelectContent>
              </Select>
            </CardContent>
          </Card>

          <Card className="shadow-elegant">
            <CardHeader>
              <CardTitle>{t('settings.voiceSettings')}</CardTitle>
              <CardDescription>{t('settings.voiceDescription')}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-3">
                <Label>{t('settings.voiceSpeed')}: {voiceSpeed.toFixed(1)}x</Label>
                <Slider
                  value={[voiceSpeed]}
                  onValueChange={handleVoiceSpeedChange}
                  min={0.5}
                  max={2}
                  step={0.1}
                  className="w-full"
                />
              </div>
              <div className="space-y-3">
                <Label>{t('settings.voicePitch')}: {voicePitch.toFixed(1)}</Label>
                <Slider
                  value={[voicePitch]}
                  onValueChange={handleVoicePitchChange}
                  min={0.5}
                  max={2}
                  step={0.1}
                  className="w-full"
                />
              </div>
            </CardContent>
          </Card>

          <Card className="shadow-elegant">
            <CardHeader>
              <CardTitle>{t('settings.notifications')}</CardTitle>
              <CardDescription>{t('settings.notificationsDescription')}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <Label htmlFor="notifications">{t('settings.enableNotifications')}</Label>
                <Switch
                  id="notifications"
                  checked={notificationsEnabled}
                  onCheckedChange={handleNotificationsToggle}
                />
              </div>
            </CardContent>
          </Card>

          <Card className="shadow-elegant">
            <CardHeader>
              <CardTitle>{t('settings.dataPrivacy')}</CardTitle>
              <CardDescription>{t('settings.dataPrivacyDescription')}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Button onClick={exportUserData} variant="outline" className="w-full">
                <Download className="mr-2 h-4 w-4" />
                {t('settings.exportData')}
              </Button>
            </CardContent>
          </Card>

          <Card className="shadow-elegant">
            <CardHeader>
              <CardTitle>{t('settings.about')}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-sm text-muted-foreground">
              <p><strong>{t('app.name')}</strong></p>
              <p>{t('settings.version')}: 1.0.0</p>
              <p>{t('settings.poweredBy')}: NextStep.AI Team</p>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
