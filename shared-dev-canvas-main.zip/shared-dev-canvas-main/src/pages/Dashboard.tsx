import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { MessageSquare, Map, BookOpen, Target, LogOut, RefreshCw, MessageCircle, Brain, TrendingUp } from 'lucide-react';
import { motion } from 'framer-motion';
import { useToast } from '@/hooks/use-toast';
import { usePullToRefresh } from '@/hooks/usePullToRefresh';

interface Conversation {
  id: string;
  title: string;
  messages: any[];
  created_at: string;
}

interface CareerInsight {
  skill: string;
  level: 'High' | 'Medium' | 'Low';
}

export default function Dashboard() {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [profile, setProfile] = useState<any>(null);
  const [stats, setStats] = useState({ conversations: 0, roadmaps: 0, skills: 0 });
  const [recentConversations, setRecentConversations] = useState<Conversation[]>([]);
  const [careerInsights, setCareerInsights] = useState<CareerInsight[]>([
    { skill: 'AI/Machine Learning', level: 'High' },
    { skill: 'Data Analysis', level: 'Medium' },
    { skill: 'Problem Solving', level: 'High' }
  ]);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    const { data: profileData } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', user.id)
      .maybeSingle();

    setProfile(profileData);

    const { count: conversationsCount } = await supabase
      .from('conversations')
      .select('*', { count: 'exact', head: true })
      .eq('user_id', user.id);

    const { count: roadmapsCount } = await supabase
      .from('roadmaps')
      .select('*', { count: 'exact', head: true })
      .eq('user_id', user.id);

    const { data: conversationsData } = await supabase
      .from('conversations')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false })
      .limit(3);

    setRecentConversations(conversationsData || []);

    const skillsLearned = profileData?.career_interests?.length || 1;

    setStats({
      conversations: conversationsCount || 0,
      roadmaps: roadmapsCount || 0,
      skills: skillsLearned
    });
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    navigate('/');
  };

  const { containerRef, isPulling, isRefreshing, pullDistance } = usePullToRefresh({
    onRefresh: loadData,
    threshold: 80
  });

  const getLevelColor = (level: string) => {
    switch (level) {
      case 'High':
        return 'bg-emerald-100 text-emerald-700 border-emerald-200';
      case 'Medium':
        return 'bg-amber-100 text-amber-700 border-amber-200';
      default:
        return 'bg-slate-100 text-slate-700 border-slate-200';
    }
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.1 }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 }
  };

  return (
    <div
      ref={containerRef}
      className="min-h-screen bg-gradient-to-br from-[#f8f9ff] via-[#fefeff] to-[#f5f7ff] overflow-y-auto"
      style={{ touchAction: 'pan-y' }}
    >
      {(isPulling || isRefreshing) && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="fixed top-0 left-1/2 -translate-x-1/2 z-50 pt-4"
        >
          <div className="bg-white rounded-full p-3 shadow-lg">
            <RefreshCw
              className={`h-5 w-5 text-[#7a5cf5] ${isRefreshing ? 'animate-spin' : ''}`}
              style={{
                transform: isPulling ? `rotate(${pullDistance * 3}deg)` : undefined
              }}
            />
          </div>
        </motion.div>
      )}

      <div className="container mx-auto px-4 py-8 max-w-7xl">
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="space-y-8"
        >
          <motion.div variants={itemVariants} className="flex justify-between items-start">
            <div>
              <h1 className="text-4xl font-bold text-gray-900 mb-2">
                Welcome back, {profile?.full_name || 'User'}! <span className="inline-block animate-wave">👋</span>
              </h1>
              <p className="text-lg text-gray-600">
                Continue your career discovery journey with your AI mentor
              </p>
            </div>
            <Button variant="ghost" onClick={handleLogout} className="text-gray-600 hover:text-gray-900">
              <LogOut className="mr-2 h-4 w-4" />
              {t('dashboard.logout')}
            </Button>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <motion.div variants={itemVariants}>
              <Card
                className="shadow-lg hover:shadow-xl transition-all duration-300 border-0 cursor-pointer group"
                onClick={() => navigate('/chat')}
              >
                <CardContent className="pt-6">
                  <div className="flex flex-col items-center text-center space-y-3">
                    <div className="w-14 h-14 rounded-full bg-blue-100 flex items-center justify-center group-hover:scale-110 transition-transform">
                      <MessageSquare className="h-7 w-7 text-blue-600" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-900 mb-1">New Chat</h3>
                      <p className="text-sm text-gray-600">Start a conversation with your AI mentor</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div variants={itemVariants}>
              <Card className="shadow-lg border-0">
                <CardContent className="pt-6">
                  <div className="flex flex-col items-center text-center space-y-3">
                    <div className="w-14 h-14 rounded-full bg-blue-100 flex items-center justify-center">
                      <MessageCircle className="h-7 w-7 text-blue-500" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-900 mb-1">Total Chats</h3>
                      <p className="text-3xl font-bold text-[#7a5cf5]">{stats.conversations}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div variants={itemVariants}>
              <Card className="shadow-lg border-0">
                <CardContent className="pt-6">
                  <div className="flex flex-col items-center text-center space-y-3">
                    <div className="w-14 h-14 rounded-full bg-green-100 flex items-center justify-center">
                      <Target className="h-7 w-7 text-green-600" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-900 mb-1">Career Paths</h3>
                      <p className="text-3xl font-bold text-[#7a5cf5]">{stats.roadmaps}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div variants={itemVariants}>
              <Card className="shadow-lg border-0">
                <CardContent className="pt-6">
                  <div className="flex flex-col items-center text-center space-y-3">
                    <div className="w-14 h-14 rounded-full bg-orange-100 flex items-center justify-center">
                      <BookOpen className="h-7 w-7 text-orange-600" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-900 mb-1">Skills Learned</h3>
                      <p className="text-3xl font-bold text-[#7a5cf5]">{stats.skills}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <motion.div variants={itemVariants} className="lg:col-span-2">
              <Card className="shadow-lg border-0">
                <CardHeader>
                  <div className="flex items-center gap-2">
                    <MessageSquare className="h-5 w-5 text-[#7a5cf5]" />
                    <CardTitle className="text-xl">Recent Conversations</CardTitle>
                  </div>
                  <CardDescription>Your latest interactions with the AI mentor</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {recentConversations.length > 0 ? (
                    recentConversations.map((conv) => (
                      <motion.div
                        key={conv.id}
                        whileHover={{ x: 4 }}
                        className="flex items-start gap-4 p-4 rounded-lg bg-gray-50 hover:bg-gray-100 transition-colors cursor-pointer"
                        onClick={() => navigate('/history')}
                      >
                        <div className="flex-shrink-0 w-2 h-2 bg-[#7a5cf5] rounded-full mt-2"></div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between mb-1">
                            <h4 className="font-semibold text-gray-900 truncate">
                              {new Date(conv.created_at).toLocaleDateString('en-US', {
                                month: 'short',
                                day: 'numeric',
                                year: 'numeric'
                              })}
                            </h4>
                            <span className="text-sm text-gray-500">
                              {Array.isArray(conv.messages) ? conv.messages.length : 0} messages
                            </span>
                          </div>
                          <p className="text-sm text-gray-600 line-clamp-2">
                            {conv.title || "Hello! I'm your AI career mentor. I'm here to help you discover the perfect career path based on your interests, skills, and aspirations..."}
                          </p>
                        </div>
                      </motion.div>
                    ))
                  ) : (
                    <div className="text-center py-8 text-gray-500">
                      <MessageSquare className="h-12 w-12 mx-auto mb-3 text-gray-300" />
                      <p>No conversations yet. Start your first chat!</p>
                      <Button
                        className="mt-4"
                        onClick={() => navigate('/chat')}
                      >
                        Continue Conversation
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            </motion.div>

            <motion.div variants={itemVariants} className="space-y-6">
              <Card className="shadow-lg border-0">
                <CardHeader>
                  <div className="flex items-center gap-2">
                    <TrendingUp className="h-5 w-5 text-[#7a5cf5]" />
                    <CardTitle className="text-xl">Career Insights</CardTitle>
                  </div>
                  <CardDescription>Based on your conversations</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  {careerInsights.map((insight, index) => (
                    <div key={index} className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 bg-[#7a5cf5] rounded-full"></div>
                        <span className="text-sm font-medium text-gray-900">{insight.skill}</span>
                      </div>
                      <Badge className={`${getLevelColor(insight.level)} border`}>
                        {insight.level}
                      </Badge>
                    </div>
                  ))}
                </CardContent>
              </Card>

              <Card className="shadow-lg border-0 bg-gradient-to-br from-[#7a5cf5] to-[#6a4ce5] text-white overflow-hidden relative">
                <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -mr-16 -mt-16"></div>
                <div className="absolute bottom-0 left-0 w-24 h-24 bg-white/10 rounded-full -ml-12 -mb-12"></div>
                <CardContent className="pt-6 relative z-10">
                  <div className="text-center space-y-4">
                    <div className="w-16 h-16 rounded-full bg-white/20 flex items-center justify-center mx-auto backdrop-blur-sm">
                      <Brain className="h-8 w-8 text-white" />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold mb-2">Ready for More?</h3>
                      <p className="text-sm text-white/90 mb-6">
                        Continue exploring career paths and get personalized recommendations
                      </p>
                    </div>
                    <Button
                      className="w-full bg-white text-[#7a5cf5] hover:bg-gray-100 font-semibold shadow-lg"
                      onClick={() => navigate('/chat')}
                    >
                      Chat with AI Mentor
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </motion.div>
      </div>

      <style>{`
        @keyframes wave {
          0%, 100% { transform: rotate(0deg); }
          25% { transform: rotate(20deg); }
          75% { transform: rotate(-20deg); }
        }
        .animate-wave {
          animation: wave 2s ease-in-out infinite;
          display: inline-block;
          transform-origin: 70% 70%;
        }
      `}</style>
    </div>
  );
}
