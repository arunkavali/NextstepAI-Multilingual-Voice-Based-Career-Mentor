import { useState, useCallback } from 'react';
import { useTranslation } from 'react-i18next';
import { supabase } from '@/integrations/supabase/client';

type Message = {
  role: 'user' | 'assistant';
  content: string;
};

export const useCareerChat = () => {
  const { i18n } = useTranslation();
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [conversationId, setConversationId] = useState<string | null>(null);

  const sendMessage = useCallback(async (userMessage: string) => {
    const newUserMessage: Message = { role: 'user', content: userMessage };
    setMessages(prev => [...prev, newUserMessage]);
    setIsLoading(true);
    setError(null);

    try {
      const CHAT_URL = `https://lfzzvxnlywdtlijemkmn.supabase.co/functions/v1/career-chat`;
      
      const response = await fetch(CHAT_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          messages: [...messages, newUserMessage],
          language: i18n.language,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error || `HTTP error! status: ${response.status}`);
      }

      if (!response.body) {
        throw new Error('No response body');
      }

      // Handle streaming response
      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let assistantMessage = '';

      // Add empty assistant message that we'll update
      setMessages(prev => [...prev, { role: 'assistant', content: '' }]);

      let buffer = '';
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() || '';

        for (let line of lines) {
          if (line.startsWith(':') || line.trim() === '') continue;
          if (!line.startsWith('data: ')) continue;

          const jsonStr = line.slice(6).trim();
          if (jsonStr === '[DONE]') continue;

          try {
            const parsed = JSON.parse(jsonStr);
            const content = parsed.choices?.[0]?.delta?.content;
            if (content) {
              assistantMessage += content;
              setMessages(prev => {
                const newMessages = [...prev];
                newMessages[newMessages.length - 1] = {
                  role: 'assistant',
                  content: assistantMessage
                };
                return newMessages;
              });
            }
          } catch (e) {
            console.warn('Failed to parse SSE line:', e);
          }
        }
      }

      setIsLoading(false);
    } catch (err) {
      console.error('Chat error:', err);
      setError(err instanceof Error ? err.message : 'Failed to send message');
      setIsLoading(false);
      // Remove the failed message
      setMessages(prev => prev.slice(0, -1));
    }
  }, [messages, i18n.language]);

  const saveConversation = useCallback(async () => {
    if (messages.length === 0) return;

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      // Extract title from first user message
      const firstUserMsg = messages.find(m => m.role === 'user');
      const title = firstUserMsg?.content.substring(0, 100) || 'Untitled Conversation';

      if (conversationId) {
        // Update existing conversation
        await supabase
          .from('conversations')
          .update({
            messages,
            title,
            language: i18n.language,
            updated_at: new Date().toISOString(),
          })
          .eq('id', conversationId);
      } else {
        // Create new conversation
        const { data } = await supabase
          .from('conversations')
          .insert({
            user_id: user.id,
            messages,
            title,
            language: i18n.language,
          })
          .select()
          .single();
        
        if (data) {
          setConversationId(data.id);
        }
      }
    } catch (err) {
      console.error('Failed to save conversation:', err);
    }
  }, [messages, conversationId, i18n.language]);

  const clearChat = useCallback(() => {
    setMessages([]);
    setError(null);
    setConversationId(null);
  }, []);

  return {
    messages,
    isLoading,
    error,
    conversationId,
    sendMessage,
    saveConversation,
    clearChat,
  };
};
