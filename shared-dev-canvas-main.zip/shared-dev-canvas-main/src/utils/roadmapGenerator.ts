export const generateCareerRoadmap = async (
  careerPath: string,
  userInfo?: string,
  language: string = 'en'
): Promise<{ imageUrl: string; careerPath: string; message: string }> => {
  try {
    const ROADMAP_URL = `https://lfzzvxnlywdtlijemkmn.supabase.co/functions/v1/generate-roadmap`;
    
    const response = await fetch(ROADMAP_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        careerPath,
        userInfo,
        language,
      }),
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw new Error(errorData.error || 'Failed to generate roadmap');
    }

    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Roadmap generation error:', error);
    throw error;
  }
};

export const downloadRoadmapImage = (imageUrl: string, filename: string = 'career-roadmap.png') => {
  const link = document.createElement('a');
  link.href = imageUrl;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};
